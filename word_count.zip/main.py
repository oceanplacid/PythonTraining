# Read text from a file, and count the occurence of words in that text
# Example:
# count_words("The cake is done. It is a big cake!") 
# --> {"cake":2, "big":1, "is":2, "the":1, "a":1, "it":1}

from collections import Counter


filename = ""

def read_file_content(filename):
    
    filename = "story"
   
    try:
       
        with open (filename+'.txt') as r:
            read_content = r.read()
        
            return read_content
        
    except:
        return (filename +" not found!")
        
    

def count_words():
    text = read_file_content("./story.txt").casefold()
    # [assignment] Add your code here
    
    word_count = Counter(text.split())

    return (word_count)
    


print (read_file_content(filename))
print()
print (count_words())